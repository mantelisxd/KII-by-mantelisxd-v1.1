# --- ADMIN CHECK -------------------------
$IsAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole(
    [Security.Principal.WindowsBuiltInRole] "Administrator"
)

if (-not $IsAdmin) {
    # Relaunch silently with admin (NO powershell window)
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = "powershell.exe"
    $psi.Arguments = "-ExecutionPolicy Bypass -WindowStyle Hidden -File `"$PSCommandPath`""
    $psi.Verb = "runas"
    $psi.WindowStyle = "Hidden"
    [System.Diagnostics.Process]::Start($psi) | Out-Null
    exit
}

# --- Sukuriam nuorodą ant Desktop į batch failą ---
$desktopPath = [Environment]::GetFolderPath("Desktop")
$linkPath = Join-Path $desktopPath "KII by mantelisxd.lnk"

$batchFileName = "paleidiklis.bat"
$batchFullPath = Join-Path $PSScriptRoot $batchFileName

# Patikrinam, ar batch failas egzistuoja
if (-not (Test-Path $batchFullPath)) {
    [System.Windows.MessageBox]::Show("Batch failas nerastas:`n$batchFullPath", "Klaida")
} else {
    if (-not (Test-Path $linkPath)) {
        $WshShell = New-Object -ComObject WScript.Shell
        $shortcut = $WshShell.CreateShortcut($linkPath)
        $shortcut.TargetPath = $batchFullPath
        $shortcut.WorkingDirectory = $PSScriptRoot
        $shortcut.WindowStyle = 1

        # Automatinis ikonų pasirinkimas
        $icoFile = Join-Path $PSScriptRoot "KII.ico"  # ieškome .ico tame pačiame aplanke
        if (Test-Path $icoFile) {
            $shortcut.IconLocation = $icoFile
        } else {
            # Jei failo nėra, naudosime numatytą sistemos ikoną
            $shortcut.IconLocation = "shell32.dll, 128"
        }

        $shortcut.Save()
    }
}

# --- GUI START -------------------------------------------------------
Add-Type -AssemblyName PresentationFramework

[xml]$xaml = @"
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        Title="KII by mantelisxd v1.1" Height="300" Width="400" ResizeMode="NoResize">
  <StackPanel Margin="10">
    <TextBlock Text="Pasirinkite veiksma:" FontSize="14" Margin="0,0,0,5"/>
    <ComboBox Name="ActionBox">
      <ComboBoxItem Content="Atsijungti (Log Out)" />
      <ComboBoxItem Content="Isjungti (Shut Down)" />
      <ComboBoxItem Content="Perkrauti (Restart)" />
      <ComboBoxItem Content="Safe Mode" />
      <ComboBoxItem Content="Normal Mode" />
    </ComboBox>
    <TextBlock Text="Laikas iki veiksmo (sek arba HH:MM arba HH:MM:SS):" Margin="0,10,0,5"/>
    <TextBox Name="DelayBox" Text="10"/>
    <TextBlock Name="CountdownText" Text="" FontSize="16" Margin="0,10,0,5" HorizontalAlignment="Center"/>
    <ProgressBar Name="ProgressBar" Height="20" Minimum="0" Maximum="100" Margin="0,5,0,5"/>
    <StackPanel Orientation="Horizontal" HorizontalAlignment="Center" Margin="0,10,0,0">
      <Button Name="GoBtn" Content="Vykdyti" Width="80" Margin="5"/>
      <Button Name="CancelBtn" Content="Atsaukti" Width="80" Margin="5"/>
      <Button Name="OpenFileBtn" Content="Info" Width="80" Margin="5"/>
    </StackPanel>
  </StackPanel>
</Window>
"@

$reader = (New-Object System.Xml.XmlNodeReader $xaml)
$window = [Windows.Markup.XamlReader]::Load($reader)
$global:TempReadOnlyFile = $null
$actionBox   = $window.FindName("ActionBox")
$actionBox.SelectedIndex = 1
$delayBox    = $window.FindName("DelayBox")
$goBtn       = $window.FindName("GoBtn")
$cancelBtn   = $window.FindName("CancelBtn")
$openFileBtn = $window.FindName("OpenFileBtn")
$countdownText = $window.FindName("CountdownText")
$progressBar = $window.FindName("ProgressBar")

$timer = New-Object System.Windows.Threading.DispatcherTimer
$timer.Interval = [TimeSpan]::FromSeconds(1)
$global:remaining = 0
$global:total = 0
$cancelled = $false

$timer.Add_Tick({
    if ($global:remaining -le 0) {
        $timer.Stop()
        $countdownText.Text = "00:00:00"
        Start-Sleep -Seconds 1
        if (-not $cancelled) {
            switch ($actionBox.SelectedIndex) {
                0 { shutdown /l /f }
                1 { shutdown /s /f /t 0 }
                2 { shutdown /r /f /t 0 }
                3 { bcdedit /set {current} safeboot minimal; Start-Sleep -Seconds 2; shutdown /r /f /t 0 }
                4 { bcdedit /deletevalue {current} safeboot; Start-Sleep -Seconds 2; shutdown /r /f /t 0 }
            }
        }
        $window.Close()
    } else {
        $global:remaining--
        $span = [TimeSpan]::FromSeconds($global:remaining)
        $countdownText.Text = $span.ToString("hh\:mm\:ss")
        if ($global:total -gt 0) {
            $progressBar.Value = 100 * ($global:total - $global:remaining) / $global:total
        }
    }
})

$goBtn.Add_Click({
    $input = $delayBox.Text.Trim()
    $global:total = 0

    if ($input -match '^[0-9]+$') {
        $global:total = [int]$input
    }
    elseif ($input -match '^(\d{1,2}):(\d{1,2}):(\d{1,2})$') {
        $h = [int]$matches[1]; $m = [int]$matches[2]; $s = [int]$matches[3]
        $global:total = ($h * 3600) + ($m * 60) + $s
    }
    elseif ($input -match '^(\d{1,2}):(\d{1,2})$') {
        $target = (Get-Date).Date.AddHours([int]$matches[1]).AddMinutes([int]$matches[2])
        $now = Get-Date
        if ($target -lt $now) { $target = $target.AddDays(1) }
        $global:total = [int]($target - $now).TotalSeconds
    } else {
        [System.Windows.MessageBox]::Show("Netinkamas laiko formatas.", "Klaida")
        return
    }

    if ($global:total -le 0) {
        [System.Windows.MessageBox]::Show("Iveskite laika didesni nei 0.", "Klaida")
        return
    }

    $cancelled = $false
    $global:remaining = $global:total
    $progressBar.Value = 0
    $span = [TimeSpan]::FromSeconds($global:remaining)
    $countdownText.Text = $span.ToString("hh\:mm\:ss")
    $timer.Start()
})

$cancelBtn.Add_Click({
    $timer.Stop()
    $cancelled = $true
    $countdownText.Text = "Operacija atsaukta"
})

$openFileBtn.Add_Click({
    $sourceFile = Join-Path $PSScriptRoot "readme.txt"

    if (-not (Test-Path $sourceFile)) {
        [System.Windows.MessageBox]::Show(
            "Failas nerastas:`n$sourceFile",
            "Klaida",
            "OK",
            "Error"
        )
        return
    }

    # Sukuriam TEMP kopiją
    $global:TempReadOnlyFile = Join-Path $env:TEMP "readmeKII.txt"
    Copy-Item $sourceFile $global:TempReadOnlyFile -Force

    # Read-Only kopijai
    Set-ItemProperty -Path $global:TempReadOnlyFile -Name IsReadOnly -Value $true

    # Atidarom kopiją
    Start-Process $global:TempReadOnlyFile
})

$window.Add_Closed({
    if ($global:TempReadOnlyFile -and (Test-Path $global:TempReadOnlyFile)) {
        try {
            # Nuimam Read-Only ir ištrinam
            Set-ItemProperty -Path $global:TempReadOnlyFile -Name IsReadOnly -Value $false
            Remove-Item $global:TempReadOnlyFile -Force
        } catch {
            # tyliai ignoruojam, jei failas dar atidarytas
        }
    }
})

$window.ShowDialog() | Out-Null
